<?php 

//definimos la codificaci贸n de los caracteres
define("DB_ENCODE","utf8");

//Definimos una constante como nombre del proyecto
define("PRO_NOMBRE","cc");
 
//datos de producci贸n, descomentar para pasar
define("DB_HOST","localhost");

//Nombre de la base de datos pr
define("DB_NAME", "moviles1");

//Usuario de la base de datos pr
define("DB_USERNAME", "root");

//Contrase帽a del usuario de la base de datos
define("DB_PASSWORD", "");

?>