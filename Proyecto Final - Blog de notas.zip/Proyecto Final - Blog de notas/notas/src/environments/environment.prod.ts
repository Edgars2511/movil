export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyBHQsyDpXUI_NBr3clDSTJn7kxN-y-g_9M",
    authDomain: "notas-343d0.firebaseapp.com",
    projectId: "notas-343d0",
    storageBucket: "notas-343d0.appspot.com",
    messagingSenderId: "1051760927207",
    appId: "1:1051760927207:web:52309899d54d2f11da9d42",
    measurementId: "G-XZYY48RLER"
  }
};
