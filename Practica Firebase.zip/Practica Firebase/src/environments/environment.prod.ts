export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyDmfUhh8AI02TrHOT7mchSseZY6Spa4BmQ",
    authDomain: "deviu-186a6.firebaseapp.com",
    projectId: "deviu-186a6",
    storageBucket: "deviu-186a6.appspot.com",
    messagingSenderId: "462077240740",
    appId: "1:462077240740:web:2af29c95c9412fe2464d31"
  }
};
