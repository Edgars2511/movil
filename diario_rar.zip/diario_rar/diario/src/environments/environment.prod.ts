export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyAL9rLXn4pNkbvl5T43zeGxh1wfvFjzcys",
    authDomain: "blognotas-67fd2.firebaseapp.com",
    projectId: "blognotas-67fd2",
    storageBucket: "blognotas-67fd2.appspot.com",
    messagingSenderId: "236306765385",
    appId: "1:236306765385:web:2a87a24fcc262298645198",
    measurementId: "G-2D0KVRJ12V"
  }
};
