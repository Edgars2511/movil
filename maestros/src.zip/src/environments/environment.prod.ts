export const environment = {
  production: true,
  apiKey: "AIzaSyBkN1a3FA1hoEzU4C-l50u5pU5oLBRpqpo",
  authDomain: "api-ionic-asesino-aaaa.firebaseapp.com",
  projectId: "api-ionic-asesino-aaaa",
  storageBucket: "api-ionic-asesino-aaaa.appspot.com",
  messagingSenderId: "155330980660",
  appId: "1:155330980660:web:c51c2d5f63b8ef5e1a5361",
  measurementId: "G-3W34M7B64W"
};
